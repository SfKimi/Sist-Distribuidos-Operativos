package com.example.emilio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class Tercero extends AppCompatActivity {
    Button salir;
    TextView t1;
    int a= 0;
    private Handler mHandler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tercero);
        t1=(TextView)findViewById(R.id.Frecuencia);
        salir=(Button)findViewById(R.id.Salir);
        final Random myRandon = new Random();
        final TextView textGenerateNumber = (TextView) findViewById(R.id.Frecuencia);
        salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Tercero.this, Menu.class);
                startActivity(i);
            }
        });
        // for (a=0;a<200;){
        while (a<100){
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    textGenerateNumber.setText(String.valueOf(myRandon.nextInt( 50)+55));
                }}, 5000);
            a++;

          /*if(textGenerateNumber.getText()=="0"){
            textGenerateNumber.setText("alerta");
          }*/
        }
    }
}
