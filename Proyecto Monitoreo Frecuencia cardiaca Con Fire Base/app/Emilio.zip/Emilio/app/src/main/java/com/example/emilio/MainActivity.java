package com.example.emilio;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.EventListener;

public class MainActivity extends AppCompatActivity {
    DatabaseReference Referencia_Base = FirebaseDatabase.getInstance().getReference();
    DatabaseReference Documento_Child = Referencia_Base.child("Nombre");
    private TextView mFire;
    private static  final  String TAG ="kimi" ;
    private FirebaseAuth mAuth;
    private EditText mcorreo, mContrasena;
    private Button mIniciar_Sesion;

   private FirebaseAuth.AuthStateListener mAuthListener;

    Button iniciar_sesion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mcorreo =(EditText) findViewById(R.id.et_correo);
        mContrasena = (EditText) findViewById(R.id.et_contrasena);
        mIniciar_Sesion = (Button) findViewById(R.id.iniciar_sesion);

        mAuth = FirebaseAuth.getInstance();/////
        mFire = (TextView) findViewById(R.id.Fire);
/*mAuthListener igual*/
     /*   mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                Toast.makeText(MainActivity.this, "Entro en listener", Toast.LENGTH_SHORT).show();
                if (firebaseAuth.getCurrentUser() !=null){
                    startActivity(new Intent(MainActivity.this,Menu.class));
                }else{
                    Toast.makeText(MainActivity.this, "Datos Incorrectos", Toast.LENGTH_SHORT).show();
                }


            }
        };*/

        mIniciar_Sesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( mcorreo.getText().toString() != "" || mContrasena.getText().toString() == "") {

                    Logeo();
                } else{
                    Toast.makeText(MainActivity.this, "Authentication failed.",
                            Toast.LENGTH_SHORT).show();
                }
               //Logeo();


            }
        });

       /* iniciar_sesion =(Button) findViewById(R.id.iniciar_sesion);
        iniciar_sesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Bienvendio Usuario:", Toast.LENGTH_SHORT).show();
                Intent i=new Intent(MainActivity.this, Menu.class);
                startActivity(i);
            }
        });*/
    }

    @Override
    protected void onStart() {
        super.onStart();
        //mAuth.addAuthStateListener(mAuthListener);
        Documento_Child.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
              String Nombre = dataSnapshot.getValue().toString();
              mFire.setText(Nombre);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
/*                        Logeo igual                                        */
    private void Logeo(){
String email = mcorreo.getText().toString();
String password = mContrasena.getText().toString();
        mAuth.signInWithEmailAndPassword(email, password)

                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            startActivity(new Intent(MainActivity.this,Menu.class));
                            //updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "signInWithEmail:failure", task.getException());
                            Toast.makeText(MainActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            //updateUI(null);
                        }

                        // ...
                    }
                });


    }
}
